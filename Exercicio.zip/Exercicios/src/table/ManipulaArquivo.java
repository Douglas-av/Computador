package table;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.JFileChooser;

public class ManipulaArquivo {

	
	public Queue<String> lerArquivo(){
		Queue<String> conteudo = new LinkedList<String>();
		JFileChooser janela = new JFileChooser();
        janela.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int i= janela.showSaveDialog(null);
        try {
			FileReader arquivo = new FileReader(janela.getSelectedFile());
			BufferedReader leituraArq = new BufferedReader(arquivo);
			while(leituraArq.ready()) {
				conteudo.add(leituraArq.readLine());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
        return conteudo;
	}
	
	public HashMap<String, Object[][]> inserirTabela(Queue<String> conteudo){
		String []header = conteudo.peek().toString().split(";");
		int tamanho = conteudo.size();
		Object[][] valores = new Object[conteudo.size()][header.length];
		for(int i = 0; i < tamanho; i++) {
			String [] informacoes = conteudo.remove().toString().split(";"); 
			for(int j = 0; j < header.length;j++) {
				valores[i][j] = informacoes[j];
				//System.out.println(valores[i][j]);
			}
		}
		HashMap<String, Object[][]> dict = new HashMap<String, Object[][]>();
		dict.put("Info", valores);
		
		return dict;
		
	}
	
	public Object[] cabecalho(HashMap<String, Object[][]> valores) {
		Object [] header = new Object[valores.get("Info")[0].length];
		for(int i = 0; i < valores.get("Info")[0].length; i++) {
			header[i] = valores.get("Info")[0][i];
			}
		return header;
	}
	
	public static void main(String[] args) {
		ManipulaArquivo manipula = new ManipulaArquivo();
		Queue<String> conteudo =  manipula.lerArquivo();
		
		//conteudo.forEach(item -> System.out.println(item));
//		System.out.println(conteudo.peek());
//		String [] informacoes = conteudo.peek().toString().split(";");
//		for(String i : informacoes) System.out.println(i);
		
		HashMap<String, Object[][]> valores = manipula.inserirTabela(conteudo);
		//System.out.println(valores.get("Info")[0][0]);
		
//		Object [] header = new Object[valores.get("Info")[0].length];
//		for(int i = 0; i < valores.get("Info")[0].length; i++) {
//			header[i] = valores.get("Info")[0][i];
//			}
		Object[] header = manipula.cabecalho(valores);
		
	}

}
