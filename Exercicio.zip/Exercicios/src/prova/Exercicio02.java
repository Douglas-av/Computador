package prova;

public class Exercicio02 {

	private int[] numbers;
	private int[] helper;

	private int number;

	public void sort(int[] values) {
		this.numbers = values;
		number = values.length;
		this.helper = new int[number];
		mergesort(0, number - 1);
	}

	private void mergesort(int low, int high) {
		// check if low is smaller than high, if not then the array is sorted
		if (low < high) {
			// Get the index of the element which is in the middle
			int middle = low + (high - low) / 2;
			// Sort the left side of the array
			mergesort(low, middle);
			// Sort the right side of the array
			mergesort(middle + 1, high);
			// Combine them both
			merge(low, middle, high);
		}
	}

	private void merge(int low, int middle, int high) {

		// Copy both parts into the helper array
		for (int i = low; i <= high; i++) {
			helper[i] = numbers[i];
		}

		int i = low;
		int j = middle + 1;
		int k = low;
		// Copy the smallest values from either the left or the right side back
		// to the original array
		while (i <= middle && j <= high) {
			if (helper[i] <= helper[j]) {
				numbers[k] = helper[i];
				i++;
			} else {
				numbers[k] = helper[j];
				j++;
			}
			k++;
		}
		// Copy the rest of the left side of the array into the target array
		while (i <= middle) {
			numbers[k] = helper[i];
			k++;
			i++;
		}
		// Since we are sorting in-place any leftover elements from the right side
		// are already at the right position.

	}

	public static void sort(int vetor[], int inicio, int meio, int fim) {
		int i, j, k;
		int vetorB[] = new int[vetor.length];
		for (i = inicio; i < meio; i++) {
			vetorB[i] = vetor[i];
		}
		for (j = meio + 1; j < fim; j++) {
			vetorB[fim + meio + 1 - j] = vetor[j];
		}
		i = inicio;
		j = fim;
		for (k = inicio; k < fim; k++) {
			if (vetorB[i] <= vetorB[j]) {
				vetor[k] = vetorB[i];
				i = i + 1;
			} else {
				vetor[k] = vetorB[j];
				j = j - 1;
			}
		}
	}

	public static void mergeSort(int vetor[], int inicio, int fim) {
		int meio;
		if (inicio < fim) {
			meio = (inicio + fim) / 2;
			mergeSort(vetor, inicio, meio);
			mergeSort(vetor, meio + 1, fim);
			sort(vetor, inicio, meio, fim);
		}
	}

	public static void main(String[] args) {
		int vetor[] = { 5, 9, 4, 7, 6, 2, 834, 12, 54 };
		
		Exercicio02 a = new Exercicio02();
		a.sort(vetor);
		
		a.mergesort(0, a.number-1);
		
		for(int i : vetor) {
			System.out.println(i);
		}
		
	}

}
