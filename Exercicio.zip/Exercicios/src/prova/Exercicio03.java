package prova;

public class Exercicio03 {
	
	public static int maior_numero(int vetor[], int inicio, int fim) {
		int meio = (inicio + fim) / 2;
		int n1, n2;
		if(meio > inicio) {
			n1 = maior_numero(vetor, inicio, meio);
			n2 = maior_numero(vetor, meio+1, fim);
		} else {
			n1 = vetor[inicio];
			n2 = vetor[fim];
		}
		if(n1 > n2) return n1;
		return n2;
		
	}
	
	
	public static void main(String[] args) {
		int vetor[] = {30, 5, 50, 156, 80, 1, 9, 23};
		
		int maior = maior_numero(vetor, 0, vetor.length-1);
		
		System.out.println(maior);
	}

}
